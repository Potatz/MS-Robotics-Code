package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class SampleClawPickupSubsystem {
    //TODO DECLARING ACTUATORS
    public Servo ClawRotator =null;
    public Servo Claw =null;

    public SampleClawPickupSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        ClawRotator = hardwareMap.get(Servo.class, "ClawRotator");
        Claw = hardwareMap.get(Servo.class, "Claw");
    }

    //TODO Spinny Procedures
    public void customClaw(double ClawPos) {
        Claw.setPosition(ClawPos);
    }
    public void customClawRotator(double ClawTurnPos) {
        Claw.setPosition(ClawTurnPos);
    }
}