package org.firstinspires.ftc.teamcode.IntoTheDeep.TeleOp;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorEx;

import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.SampleClawPickupSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ClimberSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ElevatorSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.Globals;
import org.firstinspires.ftc.teamcode.MecanumDrive;
//import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.SamplePickupSubsystem;

@TeleOp(group = "advanced")
public class MainTest extends LinearOpMode {
    Pose2d currentPose = new Pose2d(0, 0, 0);
    public static double botHeading;
    public double ClawRotatorPos = 0.5;
    public Boolean DriveStop = false;
    public double DriveSpeed = 0.7;
    public double ClawClosePos = 0.565; // reg claw: 0.5, lucas claw 0.565

    MecanumDrive drive =null;
    ClimberSubsystem climber =null;
    ElevatorSubsystem elevator =null;
    //SamplePickupSubsystem samplePickup =null;
    SampleClawPickupSubsystem samplePickup =null;

    @Override
    public void runOpMode() throws InterruptedException {
        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        climber = new ClimberSubsystem(hardwareMap, telemetry);
        elevator = new ElevatorSubsystem(hardwareMap, telemetry);
        //samplePickup = new SamplePickupSubsystem(hardwareMap, telemetry);
        samplePickup = new SampleClawPickupSubsystem(hardwareMap, telemetry);

        while (opModeInInit()) {
            gamepad1.rumble(1, 1, 400);
            telemetry.addData("Status", "Initialized");
            telemetry.update();

            samplePickup.Claw.setPosition(0.5);
            samplePickup.ClawRotator.setPosition(ClawRotatorPos);
        }

        waitForStart();

        if (isStopRequested()) return;

        while (opModeIsActive() && !isStopRequested()) {
            botHeading = drive.getRawExternalHeading();
            drive.DriveFieldCentric(-gamepad1.left_stick_x*DriveSpeed, -gamepad1.left_stick_y*DriveSpeed, gamepad1.right_stick_x*DriveSpeed, botHeading);

            //double elevatorPos = elevator.ExtenderMotor.getCurrentPosition();
            double elevatorPos = elevator.ExtenderMotor.getCurrentPosition();
            double ClimberTurnPos = elevator.ExtenderMotor.getCurrentPosition();

            //Elevator up/down and left/right
            if (gamepad1.right_bumper) {
                if (elevatorPos < -11555) {
                    elevator.elevatorStop();
                } else {
                    elevator.elevatorExtend();
                }
            } else if (gamepad1.left_bumper) {
                if (elevatorPos > -69) {
                    elevator.elevatorStop();
                } else {
                    elevator.elevatorRetract();
                }
            } else {
                elevator.elevatorStop();
            }

            if (gamepad1.left_trigger > 0.3) {
                elevator.elevatorTL();
            } else if (gamepad1.right_trigger > 0.3){
                elevator.elevatorTR();
            } else {
                elevator.elevatorTurnStop();
            }

            if (gamepad1.left_trigger > 0.1) {
                Globals.elevatorpowerL = gamepad1.left_trigger;
                Globals.elevatorTL = Globals.elevatorpowerL;
            }
            if (gamepad1.right_trigger > 0.1) {
                Globals.elevatorpowerR = (gamepad1.right_trigger * -1);
                Globals.elevatorTR = Globals.elevatorpowerR;
            }

            //Climber left/right and up/down
            if (gamepad1.dpad_up) {
                climber.climberExtend();
            } else if (gamepad1.dpad_down) {
                climber.climberRetract();
            } else if (gamepad1.dpad_left) {
                climber.climberTL();
                telemetry.addData("DpadLeft: ", gamepad1.dpad_left);
                Globals.foo = 2;
                Globals.bar = 2;
            } else if (gamepad1.dpad_right) {
                climber.climberTR();
                telemetry.addData("DpadRight: ", gamepad1.dpad_right);
                Globals.foo = -2.0;
                Globals.bar = -2.0;
            } else {
                climber.climberTurnStop();
                climber.climberStop();
            }

            //Sample intake start, stop and direction change
//            if (gamepad1.a) {
//                samplePickup.spinnyR();
//            } else if (gamepad1.b) {
//                samplePickup.spinnyL();
//            } else {
//                samplePickup.spinnyStop();
//            }
//
//            //Trapdoor open/close
//            if (gamepad1.x) {
//                samplePickup.customTrapdoor(Globals.TrapdoorOpen);
//            } else if (gamepad1.y) {
//                samplePickup.customTrapdoor(Globals.TrapdoorInnit);
//            }

            if (gamepad1.a) {
                samplePickup.Claw.setPosition(0.313);
            }
            if (gamepad1.b) {
                samplePickup.Claw.setPosition(ClawClosePos);
            }
            if (gamepad1.x) {
                ClawRotatorPos += 0.006;
                samplePickup.ClawRotator.setPosition(ClawRotatorPos);
            }
            if (gamepad1.y) {
                ClawRotatorPos -= 0.006;
                samplePickup.ClawRotator.setPosition(ClawRotatorPos);
            }


            //Telemetry info
            telemetry.addData("heading: ", botHeading);
            telemetry.addData("foo: ", Globals.foo);
            telemetry.addData("bar: ", Globals.bar);
            //telemetry.addData("elevatorPos", elevatorPos);
            telemetry.addData("elevatorTurnPos", elevatorPos);
            telemetry.addData("climberPos", climber.ClimberMotor.getCurrentPosition());
            telemetry.addData("climberTurnPos", ClimberTurnPos);
            //telemetry.addData("samplePickupPos", samplePickup.SpinnyServo.getPower());
            //telemetry.addData("samplePickupPos", samplePickup.Trapdoor.getPosition());
            telemetry.addData("Status", "Running");
            telemetry.update();

        }
    }
}