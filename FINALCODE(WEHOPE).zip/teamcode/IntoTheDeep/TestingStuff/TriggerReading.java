package org.firstinspires.ftc.teamcode.IntoTheDeep.TestingStuff;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp
public class TriggerReading extends LinearOpMode {
    @Override
    public void runOpMode() throws InterruptedException {
       float leftTrigger = gamepad1.left_trigger;
       float rightTrigger = gamepad1.right_trigger;

       telemetry.addData("Left Trigger: ", leftTrigger);
       telemetry.addData("Right Trigger: ", rightTrigger);
       telemetry.update();
    }
}
