package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class ElevatorSubsystem {
    //TODO --- Actuators ---
    public DcMotorEx ElevatorMotor = null;
    public DcMotorEx ElevatorTurner = null;

    //TODO --- Constructor ---
    public ElevatorSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        //TODO --- Motor Initialization ---
        ElevatorMotor = hardwareMap.get(DcMotorEx.class, "ElevatorMotor");
        ElevatorTurner = hardwareMap.get(DcMotorEx.class, "ElevatorTurner");

        //TODO --- Motor Configuration ---
        // Reset encoders
        ElevatorMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ElevatorTurner.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        // Set run modes
        ElevatorMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ElevatorTurner.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Set zero power behavior
        ElevatorMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        ElevatorTurner.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    }

    //TODO --- Elevator Extension/Retraction ---
    public void elevatorExtend() {
        ElevatorMotor.setPower(Globals.elevatorExtend);
    }

    public void elevatorStop() {
        ElevatorMotor.setPower(Globals.elevatorStop);
    }

    public void elevatorRetract() {
        ElevatorMotor.setPower(Globals.elevatorRetract);
    }

    //TODO --- Elevator Turning ---
    public void elevatorTR() {
        ElevatorTurner.setPower(Globals.elevatorTR);
    }

    public void elevatorTL() {
        ElevatorTurner.setPower(Globals.elevatorTL);
    }

    public void elevatorTurnStop() {
        ElevatorTurner.setPower(Globals.elevatorTurnStop);
    }

    //TODO --- Custom Elevator Control (Advanced) ---
    public void setElevatorPosition(int targetPos) {
        ElevatorMotor.setTargetPosition(targetPos);
        ElevatorMotor.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        ElevatorMotor.setPower(1); // Set power to 1 to move to position
    }

    public void setElevatorTurnPosition(int targetPos) {
        ElevatorTurner.setTargetPosition(targetPos);
        ElevatorTurner.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        ElevatorTurner.setPower(1); // Set power to 1 to move to position
    }
}