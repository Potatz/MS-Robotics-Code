package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;

@Config
public class Globals {
    //TODO -- EXTENDER SYSTEM --
    public static double elevatorExtend = -1;
    public static double elevatorStop = 0;
    public static double elevatorRetract = 1;
    public static double elevatorTR = 1; // Initialize to 0 or a default value
    public static double elevatorTurnStop = 0.0;
    public static double elevatorTL = -1; // Initialize to 0 or a default value

    //TODO -- CLIMBER SYSTEM --
    public static double climberExtend = 1;
    public static double climberStop = 0;
    public static double climberRetract = -1;
    public static double climberTR = 0.5;
    public static double climberTurnStop = 0;
    public static double climberTL = -0.5;

    //TODO -- SAMPLE PICKUP SYSTEM --
    public static double SpinnyRight = 1;
    public static double SpinnyStop = 0;
    public static double SpinnyLeft = -1;
    public static double TrapdoorInnit = 0; // Initialize to a default value
    public static double TrapdoorOpen = 0.35;

    //TODO -- AUTONOMOUS STUFF --
    public static double regAutoSpeed = 0.3;

    //TODO -- TELEOP VARIABLES --
    public static double botHeading;
    public static double clawRotatorPos = 0.5;
    public static boolean driveStop = false;
    public static double driveSpeed = 0.7;
    public static double clawClosePos = 0.565; // reg claw: 0.5, lucas claw: 0.565
    public static final double CLAW_ROTATOR_INCREMENT = 0.06;
    public static final double ELEVATOR_TURN_TRIGGER_THRESHOLD = 0.1;
    public static final double DRIVE_SPEED = 0.5;

    //TODO Servo position limits (adjust as needed)
    public static final double CLAW_OPEN_POS = 0.313;
    public static final double CLAW_CLOSE_POS = 0.565;
    public static final double CLAW_ROTATOR_MIN_POS = 0.0;
    public static final double CLAW_ROTATOR_MAX_POS = 1.0;
    public static final double CLAW_INIT_POS = 0.5;
    public static final int ELEVATOR_MAX_EXTENSION = -11555;
    public static final int ELEVATOR_MIN_RETRACTION = -69;
}