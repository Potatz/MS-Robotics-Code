package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class ClimberSubsystem {
    //TODO --- Actuators ---
    public DcMotorEx ClimberMotor = null;
    public DcMotorEx ClimberTurner = null;

    //TODO --- Constructor ---
    public ClimberSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        //TODO --- Motor Initialization ---
        ClimberMotor = hardwareMap.get(DcMotorEx.class, "ClimberMotor");
        ClimberTurner = hardwareMap.get(DcMotorEx.class, "ClimberTurner");

        //TODO --- Motor Configuration ---
        //TODO Reset encoders
        ClimberMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        ClimberTurner.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);

        //TODO Set run modes
        ClimberMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        ClimberTurner.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        //TODO Set zero power behavior
        ClimberMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        ClimberTurner.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    }

    //TODO --- Climber Extension/Retraction ---
    public void climberExtend() {
        ClimberMotor.setPower(Globals.climberExtend);
    }

    public void climberStop() {
        ClimberMotor.setPower(Globals.climberStop);
    }

    public void climberRetract() {
        ClimberMotor.setPower(Globals.climberRetract);
    }

    //TODO --- Climber Turning ---
    public void climberTR() {
        ClimberTurner.setPower(Globals.climberTR);
    }

    public void climberTL() {
        ClimberTurner.setPower(Globals.climberTL);
    }

    public void climberTurnStop() {
        ClimberTurner.setPower(Globals.climberTurnStop);
    }

    //TODO --- Custom Climber Control (Advanced) ---
    public void setClimberPosition(int targetPos) {
        ClimberMotor.setTargetPosition(targetPos);
        ClimberMotor.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        ClimberMotor.setPower(1); //TODO Set power to 1 to move to position
    }

    public void setClimberTurnPosition(int targetPos) {
        ClimberTurner.setTargetPosition(targetPos);
        ClimberTurner.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
        ClimberTurner.setPower(1); //TODO Set power to 1 to move to position
    }
}