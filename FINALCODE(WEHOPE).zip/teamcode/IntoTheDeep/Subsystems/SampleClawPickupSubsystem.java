package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class SampleClawPickupSubsystem {
    //TODO --- Actuators ---
    public Servo ClawRotator = null;
    public Servo Claw = null;

    //TODO --- Constructor ---
    public SampleClawPickupSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        //TODO --- Servo Initialization ---
        ClawRotator = hardwareMap.get(Servo.class, "ClawRotator");
        Claw = hardwareMap.get(Servo.class, "Claw");

        //TODO --- Initial Claw Positions ---
        Claw.setPosition(Globals.CLAW_INIT_POS);
        ClawRotator.setPosition(Globals.clawRotatorPos);
    }

    //TODO --- Claw Controls ---
    public void setClawPosition(double position) {
        Claw.setPosition(position);
    }

    //TODO --- Claw Rotator Controls ---
    public void setClawRotatorPosition(double position) {
        ClawRotator.setPosition(position);
    }
    public void incrementClawRotator(){
        Globals.clawRotatorPos += Globals.CLAW_ROTATOR_INCREMENT;
        setClawRotatorPosition(Globals.clawRotatorPos);
    }
    public void decrementClawRotator(){
        Globals.clawRotatorPos -= Globals.CLAW_ROTATOR_INCREMENT;
        setClawRotatorPosition(Globals.clawRotatorPos);
    }
}