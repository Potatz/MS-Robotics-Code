package org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class SamplePickupSubsystem {
    //TODO --- Actuators ---
    public CRServo SpinnyServo = null;
    public Servo Trapdoor = null;

    //TODO --- Constructor ---
    public SamplePickupSubsystem(HardwareMap hardwareMap, Telemetry telemetry) {
        //TODO --- Servo Initialization ---
        SpinnyServo = hardwareMap.get(CRServo.class, "SpinnyServo");
        Trapdoor = hardwareMap.get(Servo.class, "Trapdoor");

        //TODO --- Initial Trapdoor Position ---
        Trapdoor.setPosition(Globals.TrapdoorInnit); //TODO Set to initial position
    }

    //TODO --- Spinny Servo Controls ---
    public void spinnyRight() {
        SpinnyServo.setPower(Globals.SpinnyRight);
    }

    public void spinnyStop() {
        SpinnyServo.setPower(Globals.SpinnyStop);
    }

    public void spinnyLeft() {
        SpinnyServo.setPower(Globals.SpinnyLeft);
    }

    //TODO --- Trapdoor Control ---
    public void setTrapdoorToInit() {
        Trapdoor.setPosition(Globals.TrapdoorInnit);
    }
    public void setTrapdoorToOpen() {
        Trapdoor.setPosition(Globals.TrapdoorOpen);
    }
}