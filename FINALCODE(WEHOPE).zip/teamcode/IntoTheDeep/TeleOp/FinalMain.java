package org.firstinspires.ftc.teamcode.IntoTheDeep.TeleOp;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ClimberSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ElevatorSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.Globals;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.SampleClawPickupSubsystem;
import org.firstinspires.ftc.teamcode.MecanumDrive;

@TeleOp(group = "advanced")
public class FinalMain extends LinearOpMode {
    //TODO --- Robot Subsystems ---
    private MecanumDrive drive = null;
    private ClimberSubsystem climber = null;
    private ElevatorSubsystem elevator = null;
    private SampleClawPickupSubsystem samplePickup = null;

    @Override
    public void runOpMode() throws InterruptedException {
        //TODO --- Initialize Subsystems ---
        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        climber = new ClimberSubsystem(hardwareMap, telemetry);
        elevator = new ElevatorSubsystem(hardwareMap, telemetry);
        samplePickup = new SampleClawPickupSubsystem(hardwareMap, telemetry);

        //TODO --- Initialization Phase ---
        while (opModeInInit()) {
            gamepad1.rumble(1, 1, 400); //TODO Rumble gamepad to indicate ready
            telemetry.addData("Status: ", "Initialized");
            telemetry.update();

            //TODO Set initial positions
            samplePickup.setClawPosition(Globals.CLAW_INIT_POS);
        }

        //TODO --- Wait for Start ---
        waitForStart();

        //TODO --- Exit if Stop Requested ---
        if (isStopRequested()) return;

        //TODO --- Main TeleOp Loop ---
        while (opModeIsActive() && !isStopRequested()) {
            //TODO --- Drive Controls ---
            Globals.botHeading = drive.getRawExternalHeading();
            drive.DriveFieldCentric(
                    -gamepad1.left_stick_x * Globals.DRIVE_SPEED,
                    -gamepad1.left_stick_y * Globals.DRIVE_SPEED,
                    gamepad1.right_stick_x * Globals.DRIVE_SPEED,
                    Globals.botHeading
            );

            //TODO --- Subsystem Control ---
            handleElevatorControls();
            handleClimberControls();
            handleSamplePickupControls();

            //TODO --- Telemetry ---
            telemetry.addData("Heading", Globals.botHeading);
            telemetry.addData("Elevator Turn Pos", elevator.ElevatorMotor.getCurrentPosition());
            telemetry.addData("Climber Pos", climber.ClimberMotor.getCurrentPosition());
            telemetry.addData("Status: ", "Running");
            telemetry.update();
        }
    }

    //TODO --- Elevator Controls ---
    private void handleElevatorControls() {
        double elevatorPos = elevator.ElevatorMotor.getCurrentPosition();

        //TODO Elevator Extension/Retraction
        if (gamepad1.right_bumper) {
            if (elevatorPos < Globals.ELEVATOR_MAX_EXTENSION) {
                elevator.elevatorStop(); //TODO Stop if at max extension
            } else {
                elevator.elevatorExtend(); //TODO Extend if not at max
            }
        } else if (gamepad1.left_bumper) {
            if (elevatorPos > Globals.ELEVATOR_MIN_RETRACTION) {
                elevator.elevatorStop(); //TODO Stop if at min retraction
            } else {
                elevator.elevatorRetract(); //TODO Retract if not at min
            }
        } else {
            elevator.elevatorStop(); //TODO Stop if no button pressed
        }

        //TODO Elevator Turning - Directly modify Globals
        double leftTriggerValue = gamepad1.left_trigger;
        double rightTriggerValue = gamepad1.right_trigger;

        if (leftTriggerValue > Globals.ELEVATOR_TURN_TRIGGER_THRESHOLD) {
            //TODO Turn left based on trigger value
            Globals.elevatorTL = leftTriggerValue; // Set global turn left power
            elevator.elevatorTL();
        } else if (rightTriggerValue > Globals.ELEVATOR_TURN_TRIGGER_THRESHOLD) {
            //TODO Turn right based on trigger value
            Globals.elevatorTR = -rightTriggerValue; // Set global turn right power
            elevator.elevatorTR();
        } else {
            //TODO No turning
            Globals.elevatorTL = 0;
            Globals.elevatorTR = 0;
            elevator.elevatorTurnStop();
        }
    }

    //TODO --- Climber Controls ---
    private void handleClimberControls() {
        if (gamepad1.dpad_up) {
            climber.climberExtend();
        } else if (gamepad1.dpad_down) {
            climber.climberRetract();
        } else if (gamepad1.dpad_left) {
            climber.climberTL();
            telemetry.addData("DpadLeft", gamepad1.dpad_left);
        } else if (gamepad1.dpad_right) {
            climber.climberTR();
            telemetry.addData("DpadRight", gamepad1.dpad_right);
        } else {
            climber.climberTurnStop();
            climber.climberStop();
        }
    }

    //TODO --- Sample Pickup (Claw) Controls ---
    private void handleSamplePickupControls() {
        if (gamepad1.a) {
            samplePickup.setClawPosition(Globals.CLAW_OPEN_POS); //TODO Open claw
        }
        if (gamepad1.b) {
            samplePickup.setClawPosition(Globals.CLAW_CLOSE_POS); //TODO Close claw
        }
        if (gamepad1.x) {
            samplePickup.incrementClawRotator(); //TODO NOT WORKING :(

        }
        if (gamepad1.y) {
            samplePickup.decrementClawRotator(); //TODO NOT WORKING :(
        }
    }
}