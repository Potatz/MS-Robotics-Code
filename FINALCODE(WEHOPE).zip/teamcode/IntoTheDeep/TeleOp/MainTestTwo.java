package org.firstinspires.ftc.teamcode.IntoTheDeep.TeleOp;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ClimberSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ElevatorSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.Globals;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.SampleClawPickupSubsystem;
import org.firstinspires.ftc.teamcode.MecanumDrive;

@TeleOp(group = "advanced")
public class MainTestTwo extends LinearOpMode {

    //TODO Define important variables for robot pose and subsystem states
    private Pose2d currentPose = new Pose2d(0, 0, 0);
    public static double botHeading;
    private double clawRotatorPos = 0.5;
    private boolean driveStop = false;
    private double driveSpeed = 0.7;
    private double clawClosePos = 0.565; // reg claw: 0.5, lucas claw: 0.565

    //TODO Initialize subsystem objects
    private MecanumDrive drive = null;
    private ClimberSubsystem climber = null;
    private ElevatorSubsystem elevator = null;
    private SampleClawPickupSubsystem samplePickup = null;

    @Override
    public void runOpMode() throws InterruptedException {
        //TODO Initialize subsystems
        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        climber = new ClimberSubsystem(hardwareMap, telemetry);
        elevator = new ElevatorSubsystem(hardwareMap, telemetry);
        samplePickup = new SampleClawPickupSubsystem(hardwareMap, telemetry);

        //TODO Perform setup and initialization logic
        while (opModeInInit()) {
            gamepad1.rumble(1, 1, 400);
            telemetry.addData("Status", "Initialized");
            telemetry.update();

            samplePickup.Claw.setPosition(0.5);
//            samplePickup.ClawRotator.setPosition(clawRotatorPos);
        }

        waitForStart();

        if (isStopRequested()) return;

        //TODO Main operational loop
        while (opModeIsActive() && !isStopRequested()) {
            //TODO Update robot heading and drive controls
            botHeading = drive.getRawExternalHeading();
            drive.DriveFieldCentric(
                    -gamepad1.left_stick_x * driveSpeed,
                    -gamepad1.left_stick_y * driveSpeed,
                    gamepad1.right_stick_x * driveSpeed,
                    botHeading
            );

            //TODO Get elevator and climber positions for control logic
            double elevatorPos = elevator.ElevatorMotor.getCurrentPosition();
            double climberTurnPos = climber.ClimberTurner.getCurrentPosition();

            //TODO Handle controls for elevator, climber, and sample pickup subsystems
            handleElevatorControls(elevatorPos);
            handleClimberControls();
            handleSamplePickupControls();

            //TODO Provide telemetry data for debugging and feedback
            telemetry.addData("heading", botHeading);
            telemetry.addData("elevatorTurnPos", elevatorPos);
            telemetry.addData("climberPos", climber.ClimberMotor.getCurrentPosition());
            telemetry.addData("climberTurnPos", climberTurnPos);
            telemetry.addData("Status", "Running");
            telemetry.update();
        }
    }

    //TODO Method to handle elevator controls
    private void handleElevatorControls(double elevatorPos) {
        if (gamepad1.right_bumper) {
            if (elevatorPos < -11555) {
                elevator.elevatorStop();
            } else {
                elevator.elevatorExtend();
            }
        } else if (gamepad1.left_bumper) {
            if (elevatorPos > -69) {
                elevator.elevatorStop();
            } else {
                elevator.elevatorRetract();
            }
        } else {
            elevator.elevatorStop();
        }

        if (gamepad1.left_trigger > 0.3) {
            elevator.elevatorTL();
        } else if (gamepad1.right_trigger > 0.3) {
            elevator.elevatorTR();
        } else {
            elevator.elevatorTurnStop();
        }

        if (gamepad1.left_trigger > 0.1) {
            Globals.elevatorTL = gamepad1.left_trigger;
            Globals.elevatorTL = Globals.elevatorTL;
        }
        if (gamepad1.right_trigger > 0.1) {
            Globals.elevatorTR = -gamepad1.right_trigger;
            Globals.elevatorTR = Globals.elevatorTR;
        }
    }

    //TODO Method to handle climber controls
    private void handleClimberControls() {
        if (gamepad1.dpad_up) {
            climber.climberExtend();
        } else if (gamepad1.dpad_down) {
            climber.climberRetract();
        } else if (gamepad1.dpad_left) {
            climber.climberTL();
            telemetry.addData("DpadLeft", gamepad1.dpad_left);
        } else if (gamepad1.dpad_right) {
            climber.climberTR();
            telemetry.addData("DpadRight", gamepad1.dpad_right);
        } else {
            climber.climberTurnStop();
            climber.climberStop();
        }
    }

    //TODO Method to handle sample pickup controls
    private void handleSamplePickupControls() {
        if (gamepad1.a) {
            samplePickup.Claw.setPosition(0.313);
        }
        if (gamepad1.b) {
            samplePickup.Claw.setPosition(clawClosePos);
        }
        if (gamepad1.x) {
//            clawRotatorPos += 0.006;
//            samplePickup.ClawRotator.setPosition(clawRotatorPos);
        }
        if (gamepad1.y) {
//            clawRotatorPos -= 0.006;
//            samplePickup.ClawRotator.setPosition(clawRotatorPos);
        }
    }
}
