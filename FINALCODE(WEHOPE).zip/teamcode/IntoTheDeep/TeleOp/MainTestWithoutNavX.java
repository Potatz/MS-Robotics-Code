package org.firstinspires.ftc.teamcode.IntoTheDeep.TeleOp;

import com.acmerobotics.roadrunner.Pose2d;
import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ClimberSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.ElevatorSubsystem;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.Globals;
import org.firstinspires.ftc.teamcode.IntoTheDeep.Subsystems.SampleClawPickupSubsystem;
import org.firstinspires.ftc.teamcode.MecanumDrive;

@TeleOp(group = "advanced")
public class MainTestWithoutNavX extends LinearOpMode {
    Pose2d currentPose = new Pose2d(0, 0, 0);
    public static double botHeading;
    public double ClawRotatorPos = 0.5;
    public Boolean DriveStop = false;
    public double DriveSpeed = 0.7;
    public double ClawClosePos = 0.565; // reg claw: 0.5, lucas claw 0.565

    MecanumDrive drive = null;
    ClimberSubsystem climber = null;
    ElevatorSubsystem elevator = null;
    SampleClawPickupSubsystem samplePickup = null;

    BNO055IMU imu;

    @Override
    public void runOpMode() throws InterruptedException {
        drive = new MecanumDrive(hardwareMap, new Pose2d(0, 0, 0));
        climber = new ClimberSubsystem(hardwareMap, telemetry);
        elevator = new ElevatorSubsystem(hardwareMap, telemetry);
        samplePickup = new SampleClawPickupSubsystem(hardwareMap, telemetry);

        // Initialize the IMU
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.angleUnit = BNO055IMU.AngleUnit.RADIANS;
        imu.initialize(parameters);

        while (opModeInInit()) {
            gamepad1.rumble(1, 1, 400);
            telemetry.addData("Status", "Initialized");
            telemetry.update();

            samplePickup.Claw.setPosition(0.5);
            samplePickup.ClawRotator.setPosition(ClawRotatorPos);
        }

        waitForStart();

        if (isStopRequested()) return;

        while (opModeIsActive() && !isStopRequested()) {
            // Get heading from the IMU
            botHeading = getHeading();
            drive.DriveFieldCentric(-gamepad1.left_stick_x * DriveSpeed, -gamepad1.left_stick_y * DriveSpeed, gamepad1.right_stick_x * DriveSpeed, botHeading);

            double elevatorPos = elevator.ElevatorMotor.getCurrentPosition();
            double ClimberTurnPos = climber.ClimberTurner.getCurrentPosition();

            // Elevator controls
            if (gamepad1.right_bumper) {
                if (elevatorPos < -11555) {
                    elevator.elevatorStop();
                } else {
                    elevator.elevatorExtend();
                }
            } else if (gamepad1.left_bumper) {
                if (elevatorPos > -69) {
                    elevator.elevatorStop();
                } else {
                    elevator.elevatorRetract();
                }
            } else {
                elevator.elevatorStop();
            }

            if (gamepad1.left_trigger > 0.3) {
                elevator.elevatorTL();
            } else if (gamepad1.right_trigger > 0.3) {
                elevator.elevatorTR();
            } else {
                elevator.elevatorTurnStop();
            }

            if (gamepad1.left_trigger > 0.1) {
                Globals.elevatorTL = gamepad1.left_trigger;
                Globals.elevatorTL = Globals.elevatorTL;
            }
            if (gamepad1.right_trigger > 0.1) {
                Globals.elevatorTR = (gamepad1.right_trigger * -1);
                Globals.elevatorTR = Globals.elevatorTR;
            }

            // Climber controls
            if (gamepad1.dpad_up) {
                climber.climberExtend();
            } else if (gamepad1.dpad_down) {
                climber.climberRetract();
            } else if (gamepad1.dpad_left) {
                climber.climberTL();
                telemetry.addData("DpadLeft: ", gamepad1.dpad_left);
            } else if (gamepad1.dpad_right) {
                climber.climberTR();
                telemetry.addData("DpadRight: ", gamepad1.dpad_right);
            } else {
                climber.climberTurnStop();
                climber.climberStop();
            }

            // Claw controls
            if (gamepad1.a) {
                samplePickup.Claw.setPosition(0.313);
            }
            if (gamepad1.b) {
                samplePickup.Claw.setPosition(ClawClosePos);
            }
            if (gamepad1.x) {
                ClawRotatorPos += 0.006;
                samplePickup.ClawRotator.setPosition(ClawRotatorPos);
            }
            if (gamepad1.y) {
                ClawRotatorPos -= 0.006;
                samplePickup.ClawRotator.setPosition(ClawRotatorPos);
            }

            // Telemetry
            telemetry.addData("heading: ", botHeading);
            telemetry.addData("elevatorTurnPos", elevatorPos);
            telemetry.addData("climberPos", climber.ClimberMotor.getCurrentPosition());
            telemetry.addData("climberTurnPos", ClimberTurnPos);
            telemetry.addData("Status", "Running");
            telemetry.update();
        }
    }

    // Method to get the current heading from the IMU
    private double getHeading() {
        return imu.getAngularOrientation().firstAngle;
    }
}
